function StatusPanel({
                         algorithm = "Dijkstra",
                         startNode = null,
                         endNode = null,
                         trafficRoads = [],
                         blockedRoads = [],
                     }) {

    const ready = startNode && endNode;

    return (
        <div
            style={{
                border: "1px solid #233554",
                borderRadius: "12px",
                padding: "16px",
                marginBottom: "20px",
                background: "#0B1220",
                color: "white",
            }}
        >
            <h3
                style={{
                    marginTop: 0,
                    textAlign: "center",
                    color: "#38BDF8",
                }}
            >
                Live Status
            </h3>

            <p>
                <strong>Algorithm:</strong> {algorithm}
            </p>

            <p>
                <strong>Start:</strong> {startNode || "-"}
            </p>

            <p>
                <strong>Destination:</strong> {endNode || "-"}
            </p>

            <p>
                <strong>Traffic Roads:</strong> {trafficRoads.length}
            </p>

            <p>
                <strong>Blocked Roads:</strong> {blockedRoads.length}
            </p>

            <hr />

            <p
                style={{
                    color: ready ? "#22C55E" : "#F59E0B",
                    textAlign: "center",
                    fontWeight: "bold",
                }}
            >
                {ready
                    ? "🟢 Ready to Navigate"
                    : "🟠 Select Start & Destination"}
            </p>
        </div>
    );
}

export default StatusPanel;