function AboutPanel() {
    return (
        <div
            style={{
                border: "1px solid white",
                padding: "15px",
                marginBottom: "20px",
            }}
        >
            <h3>RouteOptix</h3>

            <p>
                Graph-based route optimization engine
                comparing Dijkstra's and A* algorithms
                through interactive visualization.
            </p>
        </div>
    );
}

export default AboutPanel;