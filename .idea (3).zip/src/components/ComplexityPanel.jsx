function ComplexityPanel({
                             algorithm,
                             visitedCount,
                             distance,
                         }) {
    return (
        <div
            style={{
                border: "1px solid white",
                padding: "15px",
                marginTop: "20px",
            }}
        >
            <h3>Complexity Analysis</h3>

            <p>
                <strong>Algorithm:</strong>{" "}
                {algorithm}
            </p>

            <p>
                <strong>Time:</strong>{" "}
                {algorithm === "dijkstra"
                    ? "O((V + E) log V)"
                    : "O(E log V)"}
            </p>

            <p>
                <strong>Path Cost:</strong>{" "}
                {distance ?? "-"}
            </p>

            <p>
                <strong>Space:</strong> O(V)
            </p>

            <p>
                <strong>Nodes Explored:</strong>{" "}
                {visitedCount}
            </p>
        </div>
    );
}

export default ComplexityPanel;