import "../styles/kpi.css";
import {panelStyle} from "../styles/commonStyles.js";

function KPICards({

                      fleet = [],

                      trafficRoads = [],

                      blockedRoads = [],

                  }) {

    return (

        <div className="kpi-grid">

            <Card
                title="Fleet"
                value={fleet.length}
                color="#38BDF8"
            />

            <Card
                title="Traffic"
                value={trafficRoads.length}
                color="#F59E0B"
            />

            <Card
                title="Closed"
                value={blockedRoads.length}
                color="#EF4444"
            />

            <Card
                title="Deliveries"
                value={fleet.length}
                color="#22C55E"
            />

        </div>

    );

}

export default KPICards;