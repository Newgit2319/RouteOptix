function RouteSummary({
                          startNode = null,
                          endNode = null,
                          path = [],
                          distance = null,
                          trafficRoads = [],
                          blockedRoads = [],
                      }) {
    return (
        <div
            style={{
                background: "#0B1220",
                border: "1px solid #233554",
                borderRadius: "12px",
                padding: "16px",
                marginBottom: "20px",
                color: "white",
            }}
        >
            <h3
                style={{
                    marginTop: 0,
                    color: "#38BDF8",
                }}
            >
                Current Route
            </h3>

            <p>
                <strong>Start:</strong> {startNode || "-"}
            </p>

            <p>
                <strong>Destination:</strong> {endNode || "-"}
            </p>

            <p>
                <strong>Path:</strong>
            </p>

            <p
                style={{
                    color: "#22C55E",
                    wordBreak: "break-word",
                }}
            >
                {path.length
                    ? path.join(" → ")
                    : "-"}
            </p>

            <p>
                <strong>Distance:</strong>{" "}
                {distance ?? "-"}
            </p>

            <p>
                <strong>Traffic Roads:</strong>{" "}
                {trafficRoads.length}
            </p>

            <p>
                <strong>Closed Roads:</strong>{" "}
                {blockedRoads.length}
            </p>
        </div>
    );
}

export default RouteSummary;