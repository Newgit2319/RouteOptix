function LegendPanel() {
    return (
        <div
            style={{
                border: "1px solid white",
                padding: "15px",
                marginTop: "20px",
            }}
        >
            <h3>Legend</h3>

            <p>🟢 Start Node</p>
            <p>🔴 Destination</p>
            <p>🟡 Shortest Path</p>
            <p>🟠 Visited Node</p>
            <p>🔵 Unvisited Node</p>
        </div>
    );
}

export default LegendPanel;