function MapCanvas({ children }) {

    return (

        <div
            style={{
                width: "100%",
                height: "760px",
                overflow: "hidden",
                borderRadius: "20px",
                background: "#050816",
                border: "1px solid #233554",
                boxShadow:
                    "0 0 35px rgba(0,229,255,.12)",
            }}
        >

            <svg

                viewBox="0 0 1200 800"

                width="100%"

                height="100%"

                preserveAspectRatio="xMidYMid meet"

            >

                <defs>

                    <pattern
                        id="grid"
                        width="40"
                        height="40"
                        patternUnits="userSpaceOnUse"
                    >

                        <path
                            d="M40 0 L0 0 0 40"
                            fill="none"
                            stroke="#162033"
                            strokeWidth="1"
                        />

                    </pattern>

                    <filter id="cyanGlow">

                        <feGaussianBlur
                            stdDeviation="3"
                            result="blur"
                        />

                        <feMerge>

                            <feMergeNode in="blur"/>

                            <feMergeNode in="SourceGraphic"/>

                        </feMerge>

                    </filter>

                    <filter id="orangeGlow">

                        <feGaussianBlur
                            stdDeviation="3"
                            result="blur"
                        />

                        <feMerge>

                            <feMergeNode in="blur"/>

                            <feMergeNode in="SourceGraphic"/>

                        </feMerge>

                    </filter>

                    <filter id="redGlow">

                        <feGaussianBlur
                            stdDeviation="3"
                            result="blur"
                        />

                        <feMerge>

                            <feMergeNode in="blur"/>

                            <feMergeNode in="SourceGraphic"/>

                        </feMerge>

                    </filter>

                </defs>

                <rect
                    width="100%"
                    height="100%"
                    fill="url(#grid)"
                />

                {children}

            </svg>

        </div>

    );

}

export default MapCanvas;