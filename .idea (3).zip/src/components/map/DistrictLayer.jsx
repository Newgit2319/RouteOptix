function DistrictLayer() {
    return (
        <>
            {/* Airport */}

            <rect
                x="40"
                y="20"
                width="1000"
                height="220"
                rx="18"
                fill="#071424"
            />

            {/* Warehouse */}

            <rect
                x="40"
                y="270"
                width="1000"
                height="250"
                rx="18"
                fill="#082032"
            />

            {/* Distribution */}

            <rect
                x="40"
                y="560"
                width="1000"
                height="250"
                rx="18"
                fill="#101C3A"
            />

            {/* Fleet */}

            <rect
                x="40"
                y="850"
                width="1000"
                height="250"
                rx="18"
                fill="#1A1435"
            />

            {/* Retail */}

            <rect
                x="40"
                y="1140"
                width="1000"
                height="250"
                rx="18"
                fill="#102A22"
            />

            {/* Customer */}

            <rect
                x="40"
                y="1430"
                width="1000"
                height="220"
                rx="18"
                fill="#222831"
            />
        </>
    );
}

export default DistrictLayer;