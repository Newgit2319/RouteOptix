function StatsPanel({
                        algorithm = "Dijkstra",
                        distance = null,
                        visitedCount = 0,
                        path = [],
                    }) {
    const efficiency =
        visitedCount > 0 && distance !== null
            ? ((distance / visitedCount) * 100).toFixed(1)
            : "-";

    return (
        <div
            style={{
                background: "#0B1220",
                border: "1px solid #233554",
                borderRadius: "12px",
                padding: "16px",
                marginTop: "20px",
                color: "white",
            }}
        >
            <h3
                style={{
                    marginTop: 0,
                    color: "#38BDF8",
                }}
            >
                Algorithm Stats
            </h3>

            <p>
                <strong>Algorithm:</strong> {algorithm}
            </p>

            <p>
                <strong>Distance:</strong> {distance ?? "-"}
            </p>

            <p>
                <strong>Visited Nodes:</strong> {visitedCount}
            </p>

            <p>
                <strong>Path Length:</strong> {path.length}
            </p>

            <p>
                <strong>Efficiency:</strong> {efficiency}
            </p>
        </div>
    );
}

export default StatsPanel;