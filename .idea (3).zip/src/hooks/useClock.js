import { useEffect, useState } from "react";

export default function useClock() {

    const [time, setTime] =
        useState(new Date());

    useEffect(() => {

        const timer =
            setInterval(() => {

                setTime(new Date());

            }, 1000);

        return () =>
            clearInterval(timer);

    }, []);

    return time;

}